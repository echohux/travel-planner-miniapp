# Travel Planner Mini Program · 旅途有谱

A WeChat mini-program MVP for travelers who have booked flights and hotels but still need a practical daily itinerary.

## Product problem

Trip planning often becomes a fragmented mix of notes, map searches and booking reminders. This prototype turns selected attractions and hotel location into a day-by-day plan with lightweight transport and reservation guidance.

## Product highlights

- Search and select built-in attractions in Beijing and Shanghai
- Add any place through WeChat's native map picker
- Assign places manually or generate a balanced random schedule
- Sort each day's route from the hotel using distance estimates
- Show transport suggestions and reservation reminders
- Store itineraries locally, with pin and delete controls

## Product decisions

- **Map selection instead of address parsing:** avoids unreliable geocoding during MVP validation.
- **Local data first:** keeps the prototype fast and avoids collecting user accounts or travel records.
- **Transparent estimates:** transport time and reservation rules are labelled as guidance, not real-time results.
- **Manual plus automatic planning:** supports users who want control as well as users who want speed.

## Privacy

- The public repository contains no personal WeChat AppID, map key, API key or account information.
- `project.config.json` uses WeChat's `touristappid` placeholder.
- `.env*`, `project.private.config.json`, build output and local caches are excluded.
- Itineraries are saved on the user's device and are not uploaded by this prototype.

## Run locally

```bash
pnpm install
pnpm build:weapp
```

Then import the repository into WeChat Developer Tools. Location features should be tested on a real device. See [使用文档.md](./使用文档.md) for the full Chinese guide.

## Tech

Taro 4 · React · TypeScript · Sass · WeChat Mini Program APIs

## Current limitations

This is a portfolio MVP. Attraction data is limited, transport time uses estimates, and publishing a usable WeChat experience requires the owner to provide a private AppID and complete WeChat's review process.
