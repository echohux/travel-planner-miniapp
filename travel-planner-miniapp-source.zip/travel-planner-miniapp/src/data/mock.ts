import type { Poi, Trip } from '../types/travel'

/**
 * 北京 MVP 景点库。
 * 预约规则为演示数据：放票天数/时间可能随官方政策调整，接入真实数据源前需人工核对。
 */
export const mockPois: Poi[] = [
  {
    id: 'beijing-palace-museum',
    city: '北京',
    name: '故宫博物院',
    category: '博物馆',
    address: '北京市东城区景山前街4号',
    latitude: 39.9163,
    longitude: 116.3972,
    visitMinutes: 180,
    openingHours: '08:30-16:30，周一闭馆',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '故宫博物院官方小程序',
      releaseDaysBefore: 7,
      releaseTime: '20:00',
      bookingNote: '实名预约，热门日期可能快速约满，出发前请再确认官方公告'
    }
  },
  {
    id: 'beijing-national-museum',
    city: '北京',
    name: '中国国家博物馆',
    category: '博物馆',
    address: '北京市东城区东长安街16号',
    latitude: 39.9042,
    longitude: 116.417,
    visitMinutes: 180,
    openingHours: '09:00-17:00，周一闭馆',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '国家博物馆官方预约',
      releaseDaysBefore: 7,
      releaseTime: '17:00',
      bookingNote: '实名预约，建议提前准备参观人信息'
    }
  },
  {
    id: 'beijing-capital-museum',
    city: '北京',
    name: '首都博物馆',
    category: '博物馆',
    address: '北京市西城区复兴门外大街16号',
    latitude: 39.9056,
    longitude: 116.342,
    visitMinutes: 150,
    openingHours: '09:00-17:00，周一闭馆',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '首都博物馆官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '免费预约参观，热门特展可能需单独预约'
    }
  },
  {
    id: 'beijing-tiananmen',
    city: '北京',
    name: '天安门广场',
    category: '历史人文',
    address: '北京市东城区天安门广场',
    latitude: 39.9054,
    longitude: 116.3976,
    visitMinutes: 60,
    openingHours: '全天开放，升旗时间随季节变化',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'beijing-jingshan',
    city: '北京',
    name: '景山公园',
    category: '公园',
    address: '北京市西城区景山西街44号',
    latitude: 39.9263,
    longitude: 116.3967,
    visitMinutes: 90,
    openingHours: '06:00-21:00',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'beijing-beihai',
    city: '北京',
    name: '北海公园',
    category: '公园',
    address: '北京市西城区文津街1号',
    latitude: 39.9252,
    longitude: 116.3892,
    visitMinutes: 120,
    openingHours: '06:30-21:00',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '畅游公园 / 北海公园预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '旺季建议提前预约门票'
    }
  },
  {
    id: 'beijing-temple-of-heaven',
    city: '北京',
    name: '天坛公园',
    category: '公园',
    address: '北京市东城区天坛东里甲1号',
    latitude: 39.8822,
    longitude: 116.4066,
    visitMinutes: 150,
    openingHours: '06:00-22:00',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '畅游公园',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '园区门票和祈年殿联票规则可能不同，出发前请再确认'
    }
  },
  {
    id: 'beijing-summer-palace',
    city: '北京',
    name: '颐和园',
    category: '公园',
    address: '北京市海淀区新建宫门路19号',
    latitude: 39.9999,
    longitude: 116.2755,
    visitMinutes: 180,
    openingHours: '06:30-18:00',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '颐和园官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '园内面积大，建议预留半天以上'
    }
  },
  {
    id: 'beijing-yuanmingyuan',
    city: '北京',
    name: '圆明园',
    category: '公园',
    address: '北京市海淀区清华西路28号',
    latitude: 40.0077,
    longitude: 116.2989,
    visitMinutes: 150,
    openingHours: '07:00-19:00',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '圆明园官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '可与颐和园分两天安排，避免一天过满'
    }
  },
  {
    id: 'beijing-prince-gong',
    city: '北京',
    name: '恭王府',
    category: '历史人文',
    address: '北京市西城区柳荫街甲14号',
    latitude: 39.9361,
    longitude: 116.3855,
    visitMinutes: 120,
    openingHours: '08:30-17:00',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '恭王府博物馆预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '可与什刹海、南锣鼓巷串联'
    }
  },
  {
    id: 'beijing-yonghegong',
    city: '北京',
    name: '雍和宫',
    category: '历史人文',
    address: '北京市东城区雍和宫大街12号',
    latitude: 39.9474,
    longitude: 116.4175,
    visitMinutes: 90,
    openingHours: '09:00-16:30',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '雍和宫官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '建议早到，旺季排队较长'
    }
  },
  {
    id: 'beijing-lama-confucius',
    city: '北京',
    name: '国子监 / 孔庙',
    category: '历史人文',
    address: '北京市东城区国子监街13号',
    latitude: 39.9457,
    longitude: 116.4138,
    visitMinutes: 90,
    openingHours: '08:30-16:30',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '孔庙和国子监博物馆预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '可与雍和宫同日串联'
    }
  },
  {
    id: 'beijing-nanluoguxiang',
    city: '北京',
    name: '南锣鼓巷',
    category: '街区',
    address: '北京市东城区南锣鼓巷',
    latitude: 39.9367,
    longitude: 116.4031,
    visitMinutes: 90,
    openingHours: '全天开放，建议傍晚逛',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'beijing-shichahai',
    city: '北京',
    name: '什刹海',
    category: '街区',
    address: '北京市西城区什刹海',
    latitude: 39.9404,
    longitude: 116.389,
    visitMinutes: 120,
    openingHours: '全天开放，夜间氛围更好',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'beijing-olympic-park',
    city: '北京',
    name: '奥林匹克公园',
    category: '地标',
    address: '北京市朝阳区天辰东路',
    latitude: 39.9928,
    longitude: 116.3905,
    visitMinutes: 120,
    openingHours: '园区全天开放，鸟巢水立方需另购票',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '鸟巢 / 水立方官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '仅逛园区可不预约；进入鸟巢或水立方需单独购票预约'
    }
  },
  {
    id: 'beijing-798',
    city: '北京',
    name: '798艺术区',
    category: '街区',
    address: '北京市朝阳区酒仙桥路4号',
    latitude: 39.9842,
    longitude: 116.4951,
    visitMinutes: 150,
    openingHours: '多数场馆 10:00-18:00',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'beijing-sanlitun',
    city: '北京',
    name: '三里屯',
    category: '街区',
    address: '北京市朝阳区三里屯路',
    latitude: 39.9335,
    longitude: 116.4551,
    visitMinutes: 120,
    openingHours: '全天开放，夜间更热闹',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'beijing-mutianyu',
    city: '北京',
    name: '慕田峪长城',
    category: '历史人文',
    address: '北京市怀柔区渤海镇慕田峪村',
    latitude: 40.4319,
    longitude: 116.5704,
    visitMinutes: 240,
    openingHours: '07:30-18:00',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '慕田峪长城官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '建议单独安排一天，并预留往返交通时间'
    }
  },
  {
    id: 'shanghai-the-bund',
    city: '上海',
    name: '外滩',
    category: '地标',
    address: '上海市黄浦区中山东一路',
    latitude: 31.2397,
    longitude: 121.4903,
    visitMinutes: 120,
    openingHours: '全天开放，夜景更佳',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'shanghai-yu-garden',
    city: '上海',
    name: '豫园',
    category: '历史人文',
    address: '上海市黄浦区安仁街132号',
    latitude: 31.2271,
    longitude: 121.4921,
    visitMinutes: 120,
    openingHours: '09:00-16:30',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '豫园官方预约',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '可与城隍庙、豫园老街串联游览'
    }
  },
  {
    id: 'shanghai-nanjing-road',
    city: '上海',
    name: '南京路步行街',
    category: '街区',
    address: '上海市黄浦区南京东路',
    latitude: 31.2355,
    longitude: 121.4759,
    visitMinutes: 120,
    openingHours: '全天开放',
    bookingRule: { requiresBooking: false }
  },
  {
    id: 'shanghai-disney',
    city: '上海',
    name: '上海迪士尼乐园',
    category: '主题乐园',
    address: '上海市浦东新区申迪西路753号',
    latitude: 31.1434,
    longitude: 121.6577,
    visitMinutes: 480,
    openingHours: '08:30-20:30',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '上海迪士尼度假区官方App',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '需提前购票并绑定入园日期，建议单独安排一整天'
    }
  },
  {
    id: 'shanghai-oriental-pearl',
    city: '上海',
    name: '东方明珠',
    category: '地标',
    address: '上海市浦东新区世纪大道1号',
    latitude: 31.2397,
    longitude: 121.4997,
    visitMinutes: 120,
    openingHours: '08:30-21:30',
    bookingRule: {
      requiresBooking: true,
      bookingPlatform: '东方明珠官方购票',
      releaseDaysBefore: 7,
      releaseTime: '00:00',
      bookingNote: '登塔需提前购票，旺季建议错峰'
    }
  },
  {
    id: 'shanghai-tianzifang',
    city: '上海',
    name: '田子坊',
    category: '街区',
    address: '上海市黄浦区泰康路210弄',
    latitude: 31.2113,
    longitude: 121.4659,
    visitMinutes: 120,
    openingHours: '全天开放，店铺多在 10:00 后营业',
    bookingRule: { requiresBooking: false }
  }
]

export const mockTrips: Trip[] = [
  {
    id: 'demo-beijing',
    title: '北京周末路线',
    city: '北京',
    startDate: '2026-10-10',
    endDate: '2026-10-12',
    hotel: {
      name: '北京王府井酒店',
      address: '北京市东城区王府井大街',
      latitude: 39.914,
      longitude: 116.411
    },
    flight: { arrivalAt: '2026-10-10 09:30', departureAt: '2026-10-12 19:30' },
    poiIds: ['beijing-palace-museum', 'beijing-jingshan', 'beijing-national-museum', 'beijing-temple-of-heaven'],
    dailyPoiLimit: 2
  }
]
