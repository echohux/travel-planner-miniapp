import { mockPois } from '../data/mock'
import type { Poi, Trip } from '../types/travel'

/** 合并默认景点库与行程内自定义地点 */
export function getAvailablePois(trip?: Trip): Poi[] {
  const customPois = trip?.customPois || []
  const city = trip?.city || '北京'
  return [...customPois, ...mockPois.filter((poi) => poi.city === city)]
}

/** 按行程已选 ID 解析完整地点列表，保留用户选择顺序 */
export function resolveSelectedPois(trip?: Trip): Poi[] {
  if (!trip) return []
  const available = getAvailablePois(trip)
  return trip.poiIds
    .map((id) => available.find((poi) => poi.id === id))
    .filter((poi): poi is Poi => Boolean(poi))
}

/** 根据地图选点或手动输入创建自定义地点 */
export function createCustomPoi(params: {
  name: string
  address: string
  latitude: number
  longitude: number
  city?: string
}): Poi {
  return {
    id: `custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    city: params.city || '北京',
    name: params.name.trim(),
    category: '地点',
    address: params.address.trim() || params.name.trim(),
    latitude: params.latitude,
    longitude: params.longitude,
    visitMinutes: 90,
    openingHours: '开放时间待确认',
    bookingRule: { requiresBooking: false }
  }
}
