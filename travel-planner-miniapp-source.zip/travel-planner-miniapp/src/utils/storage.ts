import Taro from '@tarojs/taro'

import { mockTrips } from '../data/mock'
import type { Trip } from '../types/travel'

const STORAGE_KEY = 'travel-planner-trips-v1'

/** 置顶行程排在前面，其余保持原有顺序 */
function sortTrips(trips: Trip[]): Trip[] {
  const pinned = trips.filter((trip) => trip.pinned)
  const normal = trips.filter((trip) => !trip.pinned)
  return [...pinned, ...normal]
}

/** 加载本地行程；首次启动显示演示行程 */
export function getTrips(): Trip[] {
  try {
    const saved = Taro.getStorageSync(STORAGE_KEY)
    return Array.isArray(saved) ? sortTrips(saved) : mockTrips
  } catch {
    return mockTrips
  }
}

/** 保存行程到小程序本地缓存 */
export function saveTrips(trips: Trip[]): void {
  Taro.setStorageSync(STORAGE_KEY, sortTrips(trips))
}

/** 通过 ID 查询行程 */
export function getTrip(id: string): Trip | undefined {
  return getTrips().find((trip) => trip.id === id)
}

/** 创建或更新行程 */
export function upsertTrip(trip: Trip): void {
  const trips = getTrips()
  const index = trips.findIndex((item) => item.id === trip.id)
  if (index < 0) trips.unshift(trip)
  else trips[index] = trip
  saveTrips(trips)
}

/** 删除行程 */
export function deleteTrip(id: string): void {
  const trips = getTrips().filter((trip) => trip.id !== id)
  saveTrips(trips)
}

/** 置顶或取消置顶行程 */
export function setTripPinned(id: string, pinned: boolean): void {
  const trips = getTrips()
  const index = trips.findIndex((trip) => trip.id === id)
  if (index < 0) return
  trips[index] = { ...trips[index], pinned }
  saveTrips(trips)
}
