import type { HotelAnchor, PlannedPoi, Poi } from '../types/travel'

interface Coordinate {
  latitude: number
  longitude: number
}

export type TravelMode = '步行' | '公交/地铁' | '打车'

export interface RouteLeg {
  fromName: string
  toName: string
  mode: TravelMode
  distanceKm: number
  minutes: number
  transitName?: string
  transitNote?: string
}

/** 计算两个经纬度点之间的直线距离，单位为千米 */
export function distanceKm(
  from: Coordinate,
  to: Coordinate
): number {
  const earthRadius = 6371
  const latitudeDelta = ((to.latitude - from.latitude) * Math.PI) / 180
  const longitudeDelta = ((to.longitude - from.longitude) * Math.PI) / 180
  const fromLatitude = (from.latitude * Math.PI) / 180
  const toLatitude = (to.latitude * Math.PI) / 180
  const value =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.sin(longitudeDelta / 2) ** 2 * Math.cos(fromLatitude) * Math.cos(toLatitude)

  return earthRadius * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value))
}

/** 估算两个地点之间的交通方式和耗时，后续可替换为高德路线 API */
export function estimateRouteLeg(
  from: Coordinate & { name: string },
  to: Coordinate & { name: string }
): RouteLeg {
  const straightDistance = distanceKm(from, to)
  const routeDistance = straightDistance * 1.25
  const mode: TravelMode = routeDistance <= 1.2 ? '步行' : routeDistance <= 5 ? '公交/地铁' : '打车'
  const speed = mode === '步行' ? 4.5 : mode === '公交/地铁' ? 20 : 28
  const minutes = Math.max(5, Math.round((routeDistance / speed) * 60) + (mode === '公交/地铁' ? 8 : 0))
  const transitRoute = getDemoTransitRoute(to.name)

  return {
    fromName: from.name,
    toName: to.name,
    mode,
    distanceKm: Number(routeDistance.toFixed(1)),
    minutes,
    transitName: mode === '公交/地铁' ? transitRoute.name : undefined,
    transitNote: mode === '公交/地铁' ? transitRoute.note : undefined
  }
}

/** 返回本地整理的地铁/交通建议；接入高德 API 后替换为真实方案 */
function getDemoTransitRoute(destinationName: string): { name: string; note: string } {
  if (destinationName.includes('故宫')) {
    return {
      name: '地铁1号线 → 天安门东站',
      note: '建议从 A 口出站，向北步行至午门购票/检票入口'
    }
  }
  if (destinationName.includes('国家博物馆')) {
    return {
      name: '地铁1号线 → 天安门东站',
      note: '建议从 B / C 口出站，向南步行至国博北门'
    }
  }
  if (destinationName.includes('天安门')) {
    return {
      name: '地铁1号线 → 天安门东站',
      note: '建议从 A / B 口出站，按现场安检指引进入广场'
    }
  }
  if (destinationName.includes('首都博物馆')) {
    return {
      name: '地铁1号线 → 木樨地站',
      note: '建议从 B1 口出站，向北步行至首都博物馆'
    }
  }
  if (destinationName.includes('天坛')) {
    return {
      name: '地铁5号线 → 天坛东门站',
      note: '建议从 A 口出站，步行至天坛东门'
    }
  }
  if (destinationName.includes('颐和园')) {
    return {
      name: '地铁4号线 → 北宫门站 / 西苑站',
      note: '去北宫门建议北宫门站 A 口；去东宫门建议西苑站 C2 口'
    }
  }
  if (destinationName.includes('圆明园')) {
    return {
      name: '地铁4号线 → 圆明园站',
      note: '建议从 B 口出站，向西步行至圆明园南门'
    }
  }
  if (destinationName.includes('南锣鼓巷')) {
    return {
      name: '地铁6号线 / 8号线 → 南锣鼓巷站',
      note: '建议从 E 口出站，步行进入南锣鼓巷'
    }
  }
  if (destinationName.includes('恭王府')) {
    return {
      name: '地铁8号线 → 什刹海站',
      note: '建议从 A2 口出站，步行至恭王府'
    }
  }
  if (destinationName.includes('什刹海')) {
    return {
      name: '地铁8号线 → 什刹海站',
      note: '建议从 A2 口出站，步行至前海/后海'
    }
  }
  if (destinationName.includes('雍和宫')) {
    return {
      name: '地铁2号线 / 5号线 → 雍和宫站',
      note: '建议从 C 口出站，向南步行至雍和宫'
    }
  }
  if (destinationName.includes('国子监') || destinationName.includes('孔庙')) {
    return {
      name: '地铁2号线 / 5号线 → 雍和宫站',
      note: '建议从 C 口出站，向西步行至国子监街'
    }
  }
  if (destinationName.includes('奥林匹克') || destinationName.includes('鸟巢')) {
    return {
      name: '地铁8号线 → 奥林匹克公园站',
      note: '建议从 B1 / B2 口出站，步行前往鸟巢、水立方'
    }
  }
  if (destinationName.includes('798')) {
    return {
      name: '地铁14号线 → 将台站',
      note: '建议从 A 口出站，再步行或短途打车进入 798'
    }
  }
  if (destinationName.includes('三里屯')) {
    return {
      name: '地铁10号线 → 团结湖站',
      note: '建议从 A 口出站，向北步行至三里屯'
    }
  }
  if (destinationName.includes('北海')) {
    return {
      name: '地铁6号线 → 北海北站',
      note: '建议从 B 口出站，步行至北海公园北门'
    }
  }
  if (destinationName.includes('慕田峪')) {
    return {
      name: '打车或旅游专线前往慕田峪',
      note: '距离市区较远，建议单独安排一天，并预留往返交通时间'
    }
  }
  if (destinationName.includes('景山')) {
    return {
      name: '地铁8号线 → 什刹海站 / 步行前往',
      note: '建议从 A2 口出站后步行，也可与故宫同日串联'
    }
  }
  if (destinationName.includes('外滩')) {
    return {
      name: '地铁2号线 / 10号线 → 南京东路站',
      note: '建议从 2 号口出站，步行约 10 分钟到外滩'
    }
  }
  if (destinationName.includes('豫园')) {
    return {
      name: '地铁10号线 / 14号线 → 豫园站',
      note: '建议从 1 号口出站，步行至豫园老街'
    }
  }
  if (destinationName.includes('南京路')) {
    return {
      name: '地铁1/2/8号线 → 人民广场站',
      note: '建议从 19 号口出站，直接进入南京路步行街'
    }
  }
  if (destinationName.includes('迪士尼')) {
    return {
      name: '地铁11号线 → 迪士尼站',
      note: '终点站下车，跟随指引步行至乐园入口'
    }
  }
  if (destinationName.includes('东方明珠')) {
    return {
      name: '地铁2号线 → 陆家嘴站',
      note: '建议从 1 号口出站，步行前往东方明珠'
    }
  }
  if (destinationName.includes('田子坊')) {
    return {
      name: '地铁9号线 → 打浦桥站',
      note: '建议从 1 号口出站，步行至田子坊'
    }
  }
  return {
    name: '建议打开地图查询公交/地铁',
    note: '打开微信地图可查看最新线路、出站口和步行路线'
  }
}

/** 打乱数组顺序 */
export function shuffleItems<T>(items: T[]): T[] {
  const next = [...items]
  for (let index = next.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1))
    const temp = next[index]
    next[index] = next[swapIndex]
    next[swapIndex] = temp
  }
  return next
}

/** 将景点随机均分到各天，返回 poiId -> 第几天 */
export function buildRandomPoiDayMap(poiIds: string[], dayCount: number): Record<string, number> {
  const safeDayCount = Math.max(1, dayCount)
  const shuffled = shuffleItems(poiIds)
  const map: Record<string, number> = {}
  shuffled.forEach((poiId, index) => {
    map[poiId] = (index % safeDayCount) + 1
  })
  return map
}

/** 按用户指定天数或距离，将景点分配为每日路线；酒店作为每天起终点锚点 */
export function buildDailyPlans(
  pois: Poi[],
  hotel: HotelAnchor,
  dayCount: number,
  options?: {
    maxPerDay?: number
    poiDayMap?: Record<string, number>
  }
): PlannedPoi[][] {
  const plans: PlannedPoi[][] = Array.from({ length: Math.max(dayCount, 1) }, () => [])
  const poiDayMap = options?.poiDayMap
  const maxPerDay = options?.maxPerDay

  if (poiDayMap && Object.keys(poiDayMap).length > 0) {
    pois.forEach((poi) => {
      const day = poiDayMap[poi.id]
      if (!day || day < 1 || day > plans.length) return
      plans[day - 1].push({ ...poi, day, order: plans[day - 1].length + 1 })
    })
  } else {
    const remaining = [...pois]
    const limit = maxPerDay && maxPerDay > 0 ? Math.floor(maxPerDay) : undefined
    remaining.sort((first, second) => distanceKm(hotel, first) - distanceKm(hotel, second))
    remaining.forEach((poi, index) => {
      const dayIndex = limit ? Math.floor(index / limit) : index % plans.length
      if (dayIndex >= plans.length) return
      plans[dayIndex].push({ ...poi, day: dayIndex + 1, order: plans[dayIndex].length + 1 })
    })
  }

  plans.forEach((plan) => {
    plan.sort((first, second) => distanceKm(hotel, first) - distanceKm(hotel, second))
    plan.forEach((poi, index) => {
      poi.order = index + 1
    })
  })

  return plans
}

/** 根据开始日期和天数计算结束日期 */
export function getEndDateByDayCount(startDate: string, dayCount: number): string {
  const date = new Date(`${startDate}T00:00:00`)
  date.setDate(date.getDate() + Math.max(dayCount, 1) - 1)
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  return `${date.getFullYear()}-${month}-${day}`
}
