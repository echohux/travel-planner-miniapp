import type { BookingReminder, BookingUrgency, Poi } from '../types/travel'

/** 将日期和放票时间组合为本地时间字符串 */
function combineDateAndTime(date: Date, time: string): Date {
  const [hours, minutes] = time.split(':').map(Number)
  const result = new Date(date)
  result.setHours(hours || 0, minutes || 0, 0, 0)
  return result
}

/** 根据游玩日期和规则反推出放票时间 */
export function getReleaseAt(visitDate: string, poi: Poi): Date | undefined {
  const rule = poi.bookingRule
  if (!rule.requiresBooking || rule.releaseDaysBefore === undefined || !rule.releaseTime) {
    return undefined
  }

  const visitAt = new Date(`${visitDate}T00:00:00`)
  visitAt.setDate(visitAt.getDate() - rule.releaseDaysBefore)
  return combineDateAndTime(visitAt, rule.releaseTime)
}

/** 计算提示语的紧迫程度 */
export function getBookingUrgency(releaseAt: Date | undefined, now = new Date()): BookingUrgency {
  if (!releaseAt) return 'normal'

  const diff = releaseAt.getTime() - now.getTime()
  if (diff <= 24 * 60 * 60 * 1000) return 'today'
  if (diff <= 3 * 24 * 60 * 60 * 1000) return 'soon'
  return 'normal'
}

/** 生成面向用户的预约提示语，不执行通知或闹钟 */
export function buildBookingReminder(poi: Poi, visitDate: string, now = new Date()): BookingReminder {
  if (!poi.bookingRule.requiresBooking) {
    return {
      poiId: poi.id,
      poiName: poi.name,
      urgency: 'normal',
      text: '无需预约，可直接前往；出发前再确认开放时间即可。'
    }
  }

  const releaseAt = getReleaseAt(visitDate, poi)
  const urgency = getBookingUrgency(releaseAt, now)
  const releaseText = releaseAt
    ? `${releaseAt.getMonth() + 1}月${releaseAt.getDate()}日 ${releaseAt.getHours().toString().padStart(2, '0')}:${releaseAt
        .getMinutes()
        .toString()
        .padStart(2, '0')}`
    : '请以官方公告为准'
  const urgencyText = urgency === 'today' ? '⚠️ 临近放票' : urgency === 'soon' ? '⏰ 近期要抢' : '📌 提前记下'

  return {
    poiId: poi.id,
    poiName: poi.name,
    releaseAt: releaseAt?.toISOString(),
    urgency,
    text: `${urgencyText}：${releaseText}放票，提前${poi.bookingRule.releaseDaysBefore}天；请在「${poi.bookingRule.bookingPlatform}」预约。${poi.bookingRule.bookingNote || ''}`
  }
}
