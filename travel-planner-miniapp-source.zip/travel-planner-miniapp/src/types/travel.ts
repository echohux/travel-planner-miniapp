export type BookingUrgency = 'normal' | 'soon' | 'today'

export interface HotelAnchor {
  name: string
  address: string
  latitude: number
  longitude: number
}

export interface FlightAnchor {
  arrivalAt?: string
  departureAt?: string
}

export interface BookingRule {
  requiresBooking: boolean
  bookingPlatform?: string
  bookingUrl?: string
  releaseDaysBefore?: number
  releaseTime?: string
  bookingNote?: string
}

export interface Poi {
  id: string
  city: string
  name: string
  category: string
  address: string
  latitude: number
  longitude: number
  visitMinutes: number
  openingHours: string
  bookingRule: BookingRule
}

export interface PlannedPoi extends Poi {
  day: number
  order: number
}

export type AssignMode = 'manual' | 'random'

export interface Trip {
  id: string
  title: string
  city: string
  startDate: string
  endDate: string
  hotel: HotelAnchor
  flight?: FlightAnchor
  poiIds: string[]
  /** 用户自行添加的地点，不在默认景点库中 */
  customPois?: Poi[]
  /** 游玩天数 */
  dayCount?: number
  /** 景点分配方式：自己分配 / 随机分配 */
  assignMode?: AssignMode
  /** 景点所属天数，key 为景点 id，value 为第几天（从 1 开始） */
  poiDayMap?: Record<string, number>
  dailyPoiLimit?: number
  /** 是否置顶 */
  pinned?: boolean
}

export interface BookingReminder {
  poiId: string
  poiName: string
  releaseAt?: string
  urgency: BookingUrgency
  text: string
}
