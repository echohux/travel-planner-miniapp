import { Button, Map, Text, View } from '@tarojs/components'
import Taro, { useLoad } from '@tarojs/taro'
import { useMemo, useState } from 'react'

import { buildBookingReminder } from '../../utils/booking'
import { resolveSelectedPois } from '../../utils/poi'
import { getTrip } from '../../utils/storage'
import { buildDailyPlans, estimateRouteLeg } from '../../utils/route'
import type { PlannedPoi, Trip } from '../../types/travel'
import './index.scss'

/** 计算两个日期之间包含的天数 */
function getDayCount(startDate: string, endDate: string): number {
  const start = new Date(`${startDate}T00:00:00`).getTime()
  const end = new Date(`${endDate}T00:00:00`).getTime()
  return Math.max(1, Math.round((end - start) / (24 * 60 * 60 * 1000)) + 1)
}

/** 将日期偏移到指定天数 */
function getDateByOffset(startDate: string, offset: number): string {
  const date = new Date(`${startDate}T00:00:00`)
  date.setDate(date.getDate() + offset)
  return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date
    .getDate()
    .toString()
    .padStart(2, '0')}`
}

export default function TripDetail() {
  // 当前行程
  const [trip, setTrip] = useState<Trip>()
  // 当前查看的天数
  const [activeDay, setActiveDay] = useState(0)

  useLoad((params) => {
    setTrip(params.id ? getTrip(params.id) : undefined)
  })

  const allPois = useMemo(() => resolveSelectedPois(trip), [trip])
  const dayCount = trip?.dayCount || getDayCount(trip?.startDate || '', trip?.endDate || '')
  const plans = useMemo(
    () =>
      trip
        ? buildDailyPlans(allPois, trip.hotel, dayCount, {
            maxPerDay: trip.dailyPoiLimit,
            poiDayMap: trip.poiDayMap
          })
        : [],
    [allPois, trip, dayCount]
  )
  const currentPlan = plans[activeDay] || []
  const currentDate = trip ? getDateByOffset(trip.startDate, activeDay) : ''
  const assignModeLabel = trip?.assignMode === 'random' ? '随机分配' : '自己分配'

  /** 打开分配页调整天数与景点分配 */
  const editPois = () => {
    if (trip) Taro.navigateTo({ url: `/pages/assign/index?tripId=${trip.id}` })
  }

  /** 打开微信地图查看当前交通段的导航路线 */
  const openMap = (latitude: number, longitude: number, name: string, address: string) => {
    Taro.openLocation({
      latitude,
      longitude,
      name,
      address,
      scale: 16
    })
  }

  if (!trip) {
    return (
      <View className='page'>
        <View className='card muted'>行程不存在，请返回重新创建。</View>
      </View>
    )
  }

  return (
    <View className='page detail-page'>
      <View className='hero'>
        <Text className='hero-title'>{trip.title}</Text>
        <Text className='hero-subtitle'>
          {trip.city} · {trip.startDate} 至 {trip.endDate}
        </Text>
      </View>

      <View className='card anchor-card'>
        <Text className='card-title'>每日路线锚点</Text>
        <Text className='muted'>
          共 {dayCount} 天 · {assignModeLabel}。每天从 {trip.hotel.name} 出发，当天景点按距离排序。
        </Text>
      </View>

      <View className='day-tabs'>
        {plans.map((_, index) => (
          <View
            className={`day-tab ${activeDay === index ? 'day-tab-active' : ''}`}
            key={`day-tab-${index}`}
            onClick={() => setActiveDay(index)}
          >
            <Text>第{index + 1}天</Text>
            <Text className='day-date'>{trip ? getDateByOffset(trip.startDate, index).slice(5) : ''}</Text>
          </View>
        ))}
      </View>

      <Map
        className='route-map'
        latitude={currentPlan[0]?.latitude || trip.hotel.latitude}
        longitude={currentPlan[0]?.longitude || trip.hotel.longitude}
        scale={12}
        onError={() => undefined}
        markers={[
          {
            id: 0,
            latitude: trip.hotel.latitude,
            longitude: trip.hotel.longitude,
            title: '酒店',
            iconPath: 'https://mapapi.qq.com/web/mapComponents/marker.png'
          },
          ...currentPlan.map((poi) => ({
            id: poi.order,
            latitude: poi.latitude,
            longitude: poi.longitude,
            title: poi.name,
            iconPath: 'https://mapapi.qq.com/web/mapComponents/marker.png'
          }))
        ]}
      />

      <Text className='section-title'>{currentDate} 路线</Text>
      {currentPlan.length ? (
        currentPlan.map((poi: PlannedPoi, index) => {
          const reminder = buildBookingReminder(poi, currentDate)
          const from = index === 0 ? { ...trip.hotel, name: trip.hotel.name } : currentPlan[index - 1]
          const leg = estimateRouteLeg(from, poi)
          return (
            <View key={poi.id}>
              <View className='transport-leg'>
                <Text className='transport-line'>↓</Text>
                <View className='transport-copy'>
                  <Text className='transport-title'>
                    {leg.mode} · 约 {leg.minutes} 分钟
                  </Text>
                  {leg.transitName && <Text className='transit-name'>{leg.transitName}</Text>}
                  <Text className='muted'>
                    {leg.fromName} → {leg.toName} · 约 {leg.distanceKm} 公里
                  </Text>
                  {leg.transitNote && <Text className='transit-note'>{leg.transitNote}</Text>}
                  <Button
                    className='map-button'
                    size='mini'
                    onClick={() => openMap(poi.latitude, poi.longitude, poi.name, poi.address)}
                  >
                    打开微信地图
                  </Button>
                </View>
              </View>
              <View className='card route-card'>
                <View className='route-heading'>
                  <View className='number'>{poi.order}</View>
                  <View className='route-copy'>
                    <Text className='card-title'>{poi.name}</Text>
                    <Text className='muted'>
                      {poi.category} · 建议停留 {poi.visitMinutes} 分钟 · {poi.openingHours}
                    </Text>
                  </View>
                </View>
                <View className={`booking-reminder booking-${reminder.urgency}`}>
                  <Text className='booking-title'>预约提示</Text>
                  <Text className='booking-text'>{reminder.text}</Text>
                </View>
              </View>
            </View>
          )
        })
      ) : (
        <View className='card muted'>今天还没有安排地点，可以点击下方按钮添加。</View>
      )}
      {currentPlan.length > 0 && (
        <View className='transport-leg transport-return'>
          <Text className='transport-line'>↓</Text>
          <View className='transport-copy'>
            {(() => {
              const lastPoi = currentPlan[currentPlan.length - 1]
              const leg = estimateRouteLeg(lastPoi, { ...trip.hotel, name: trip.hotel.name })
              return (
                <>
                  <Text className='transport-title'>
                    返回酒店 · {leg.mode} · 约 {leg.minutes} 分钟
                  </Text>
                  {leg.transitName && <Text className='transit-name'>{leg.transitName}</Text>}
                  <Text className='muted'>
                    {leg.fromName} → {leg.toName} · 约 {leg.distanceKm} 公里
                  </Text>
                  {leg.transitNote && <Text className='transit-note'>{leg.transitNote}</Text>}
                  <Button
                    className='map-button'
                    size='mini'
                    onClick={() => openMap(trip.hotel.latitude, trip.hotel.longitude, trip.hotel.name, trip.hotel.address)}
                  >
                    打开微信地图
                  </Button>
                </>
              )
            })()}
          </View>
        </View>
      )}

      <Button className='secondary-button' onClick={editPois}>
        调整地点，重新排路线
      </Button>
    </View>
  )
}
