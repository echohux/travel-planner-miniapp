import { Button, Text, View } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'

import { deleteTrip, getTrips, setTripPinned } from '../../utils/storage'
import type { Trip } from '../../types/travel'
import './index.scss'

/** 估算单张行程卡片高度，用于置顶移动动效 */
const CARD_OFFSET = 148

export default function Index() {
  // 当前本地保存的行程列表
  const [trips, setTrips] = useState<Trip[]>([])
  // 列表重排时的临时位移，实现卡片移动动效
  const [offsets, setOffsets] = useState<Record<string, number>>({})

  /** 页面展示时刷新本地行程 */
  useDidShow(() => {
    setTrips(getTrips())
  })

  /** 打开行程详情 */
  const openTrip = (id: string) => {
    Taro.navigateTo({ url: `/pages/detail/index?id=${id}` })
  }

  /** 删除行程，需二次确认 */
  const handleDelete = async (event: { stopPropagation: () => void }, trip: Trip) => {
    event.stopPropagation()
    const modal = await Taro.showModal({
      title: '删除行程',
      content: `确定删除「${trip.title}」吗？删除后不可恢复。`,
      confirmText: '删除',
      confirmColor: '#b34e3d'
    })
    if (!modal.confirm) return
    deleteTrip(trip.id)
    setTrips(getTrips())
    Taro.showToast({ title: '已删除', icon: 'success' })
  }

  /** 置顶或取消置顶，并播放卡片移动动效 */
  const handleTogglePin = (event: { stopPropagation: () => void }, trip: Trip) => {
    event.stopPropagation()
    const oldOrder = trips.map((item) => item.id)
    setTripPinned(trip.id, !trip.pinned)
    const nextTrips = getTrips()
    const nextOffsets: Record<string, number> = {}

    nextTrips.forEach((item, newIndex) => {
      const oldIndex = oldOrder.indexOf(item.id)
      if (oldIndex >= 0 && oldIndex !== newIndex) {
        nextOffsets[item.id] = (oldIndex - newIndex) * CARD_OFFSET
      }
    })

    setTrips(nextTrips)
    setOffsets(nextOffsets)
    setTimeout(() => setOffsets({}), 40)
    Taro.showToast({ title: trip.pinned ? '已取消置顶' : '已置顶', icon: 'success' })
  }

  return (
    <View className='page index-page'>
      <View className='hero'>
        <Text className='hero-title'>旅途有谱</Text>
        <Text className='hero-subtitle'>机酒定好了，每天怎么走，一次排好。</Text>
      </View>

      <Button className='primary-button' onClick={() => Taro.navigateTo({ url: '/pages/create/index' })}>
        新建一段旅程
      </Button>

      <Text className='section-title'>我的行程</Text>
      {trips.map((trip) => (
        <View
          className={`card trip-card ${offsets[trip.id] ? 'trip-card-moving' : ''}`}
          key={trip.id}
          style={{
            transform: `translateY(${offsets[trip.id] || 0}px)`
          }}
          onClick={() => openTrip(trip.id)}
        >
          <View className='trip-main'>
            <View className='trip-header'>
              <Text className='card-title'>{trip.title}</Text>
              {trip.pinned && <Text className='pin-tag'>置顶</Text>}
            </View>
            <Text className='trip-meta'>
              {trip.city} · {trip.startDate} 至 {trip.endDate}
            </Text>
            <Text className='muted'>已加入 {trip.poiIds.length} 个地点，点击查看每日路线</Text>
          </View>
          <View className='trip-actions'>
            <Button
              className='action-button pin-button'
              size='mini'
              onClick={(event) => handleTogglePin(event, trip)}
            >
              {trip.pinned ? '取消置顶' : '置顶'}
            </Button>
            <Button
              className='action-button delete-button'
              size='mini'
              onClick={(event) => handleDelete(event, trip)}
            >
              删除
            </Button>
          </View>
        </View>
      ))}
      {!trips.length && <View className='card muted'>还没有行程，先添加已经订好的酒店和想去的地点吧。</View>}
    </View>
  )
}
