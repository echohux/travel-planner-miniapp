import { Button, Input, Text, View } from '@tarojs/components'
import Taro, { useLoad } from '@tarojs/taro'
import { useEffect, useMemo, useState } from 'react'

import { resolveSelectedPois } from '../../utils/poi'
import { buildRandomPoiDayMap, getEndDateByDayCount } from '../../utils/route'
import { getTrip, upsertTrip } from '../../utils/storage'
import type { AssignMode, Trip } from '../../types/travel'
import './index.scss'

export default function AssignPage() {
  // 当前行程
  const [trip, setTrip] = useState<Trip>()
  // 游玩天数
  const [dayCount, setDayCount] = useState(3)
  // 分配方式：自己分配 / 随机分配
  const [assignMode, setAssignMode] = useState<AssignMode>('manual')
  // 景点所属天数
  const [poiDayMap, setPoiDayMap] = useState<Record<string, number>>({})

  useLoad((params) => {
    const current = params.tripId ? getTrip(params.tripId) : undefined
    setTrip(current)
    setDayCount(current?.dayCount || 3)
    setAssignMode(current?.assignMode || 'manual')
    setPoiDayMap(current?.poiDayMap || {})
  })

  const selectedPois = useMemo(() => resolveSelectedPois(trip), [trip])
  const selectedIds = trip?.poiIds || []

  /** 同步已选景点的默认天数 */
  useEffect(() => {
    if (!selectedIds.length) return
    setPoiDayMap((prev) => {
      const next: Record<string, number> = {}
      selectedIds.forEach((id, index) => {
        const existing = prev[id]
        next[id] = existing && existing >= 1 && existing <= dayCount ? existing : (index % dayCount) + 1
      })
      return next
    })
  }, [selectedIds.join(','), dayCount])

  /** 手动指定景点所属天数 */
  const setPoiDay = (poiId: string, day: number) => {
    setPoiDayMap((prev) => ({ ...prev, [poiId]: day }))
  }

  /** 随机分配已选景点到各天 */
  const handleRandomAssign = () => {
    if (!selectedIds.length) {
      Taro.showToast({ title: '请先返回选择景点', icon: 'none' })
      return
    }
    const nextMap = buildRandomPoiDayMap(selectedIds, dayCount)
    setPoiDayMap(nextMap)
    setAssignMode('random')
    Taro.showToast({ title: '已随机分配', icon: 'success' })
  }

  /** 保存分配结果并进入路线详情 */
  const handleSave = () => {
    if (!trip) return
    if (!selectedIds.length) {
      Taro.showToast({ title: '请先返回选择景点', icon: 'none' })
      return
    }

    const finalDayMap =
      assignMode === 'random'
        ? buildRandomPoiDayMap(selectedIds, dayCount)
        : selectedIds.reduce<Record<string, number>>((map, id, index) => {
            map[id] = poiDayMap[id] || (index % dayCount) + 1
            return map
          }, {})

    const nextTrip: Trip = {
      ...trip,
      endDate: getEndDateByDayCount(trip.startDate, dayCount),
      dayCount,
      assignMode,
      poiDayMap: finalDayMap
    }
    upsertTrip(nextTrip)
    Taro.redirectTo({ url: `/pages/detail/index?id=${trip.id}` })
  }

  if (!trip) {
    return (
      <View className='page'>
        <View className='card muted'>行程不存在，请返回重新创建。</View>
      </View>
    )
  }

  return (
    <View className='page assign-page'>
      <View className='card setting-card'>
        <View className='setting-row'>
          <Text className='setting-label'>游玩几天</Text>
          <View className='day-options'>
            {[1, 2, 3].map((day) => (
              <View
                className={`option-chip ${dayCount === day ? 'option-chip-active' : ''}`}
                key={`day-option-${day}`}
                onClick={() => setDayCount(day)}
              >
                <Text>{day}天</Text>
              </View>
            ))}
            <Input
              className={`option-chip day-input ${dayCount > 3 ? 'option-chip-active' : ''}`}
              type='number'
              placeholder='自定义'
              value={dayCount > 3 ? dayCount.toString() : ''}
              onInput={(event) => {
                const nextValue = Number(event.detail.value)
                if (!event.detail.value) return
                setDayCount(Math.min(30, Math.max(1, Number.isFinite(nextValue) ? nextValue : 1)))
              }}
            />
          </View>
        </View>

        <View className='setting-row'>
          <Text className='setting-label'>怎么分配</Text>
          <View className='mode-row'>
            <View
              className={`option-chip ${assignMode === 'manual' ? 'option-chip-active' : ''}`}
              onClick={() => setAssignMode('manual')}
            >
              <Text>自己分配</Text>
            </View>
            <View
              className={`option-chip ${assignMode === 'random' ? 'option-chip-active' : ''}`}
              onClick={() => setAssignMode('random')}
            >
              <Text>随机分配</Text>
            </View>
          </View>
        </View>

        {assignMode === 'random' && (
          <Button className='manual-add-button' onClick={handleRandomAssign}>
            重新随机一次
          </Button>
        )}
      </View>

      <View className='card assign-card'>
        <Text className='card-title'>已选 {selectedPois.length} 个景点</Text>

        {assignMode === 'manual'
          ? selectedPois.map((poi) => (
              <View className='assign-row' key={`assign-${poi.id}`}>
                <Text className='assign-name'>{poi.name}</Text>
                <View className='day-chip-row'>
                  {Array.from({ length: dayCount }, (_, index) => {
                    const day = index + 1
                    const active = (poiDayMap[poi.id] || 1) === day
                    return (
                      <View
                        className={`day-chip ${active ? 'day-chip-active' : ''}`}
                        key={`day-chip-${poi.id}-${day}`}
                        onClick={() => setPoiDay(poi.id, day)}
                      >
                        <Text>第{day}天</Text>
                      </View>
                    )
                  })}
                </View>
              </View>
            ))
          : Array.from({ length: dayCount }, (_, index) => {
              const day = index + 1
              const dayPois = selectedPois.filter((poi) => (poiDayMap[poi.id] || 0) === day)
              return (
                <View className='preview-day' key={`preview-day-${day}`}>
                  <Text className='preview-title'>
                    第{day}天 · {dayPois.length} 个
                  </Text>
                  <Text className='muted'>
                    {dayPois.length ? dayPois.map((poi) => poi.name).join('、') : '暂无景点'}
                  </Text>
                </View>
              )
            })}
      </View>

      <View className='bottom-spacer' />

      <View className='bottom-bar'>
        <Button className='primary-button bottom-button' onClick={handleSave}>
          生成我的路线
        </Button>
      </View>
    </View>
  )
}
