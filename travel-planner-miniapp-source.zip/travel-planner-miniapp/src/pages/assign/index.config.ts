export default definePageConfig({
  navigationBarTitleText: '分配行程'
})
