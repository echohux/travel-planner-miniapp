import { Button, Input, Text, View } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'

import { upsertTrip } from '../../utils/storage'
import type { Trip } from '../../types/travel'
import './index.scss'

export default function CreateTrip() {
  // 行程名称
  const [title, setTitle] = useState('北京周末路线')
  // 目的地城市
  const [city, setCity] = useState('北京')
  // 行程开始日期
  const [startDate, setStartDate] = useState('2026-10-10')
  // 行程结束日期
  const [endDate, setEndDate] = useState('2026-10-12')
  // 已选酒店名称（只读，来自地图选点）
  const [hotelName, setHotelName] = useState('')
  // 已选酒店地址（只读，来自地图选点）
  const [hotelAddress, setHotelAddress] = useState('')
  // 酒店纬度
  const [hotelLat, setHotelLat] = useState(0)
  // 酒店经度
  const [hotelLng, setHotelLng] = useState(0)
  // 是否已在地图上确认过酒店位置
  const [locationPicked, setLocationPicked] = useState(false)

  /** 在地图上选择酒店真实位置，拿到经纬度 */
  const handlePickHotel = async () => {
    try {
      // 首次使用先申请授权，避免「授权后还要再点一次」的问题
      const setting = await Taro.getSetting()
      const authState = setting.authSetting['scope.userLocation']
      if (authState === false) {
        const modal = await Taro.showModal({
          title: '需要位置权限',
          content: '请在设置中开启位置权限后，再选择酒店位置',
          confirmText: '去设置'
        })
        if (modal.confirm) await Taro.openSetting({})
        return
      }
      if (authState === undefined) {
        try {
          await Taro.authorize({ scope: 'scope.userLocation' })
        } catch {
          Taro.showToast({ title: '未授权位置权限', icon: 'none' })
          return
        }
      }

      const result = await Taro.chooseLocation({
        latitude: hotelLat || 39.914,
        longitude: hotelLng || 116.411
      })
      if (!result.name && !result.address) {
        Taro.showToast({ title: '未选择地点', icon: 'none' })
        return
      }
      setHotelName(result.name || result.address)
      setHotelAddress(result.address || result.name)
      setHotelLat(result.latitude)
      setHotelLng(result.longitude)
      setLocationPicked(true)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      if (message.includes('cancel') || message.includes('取消')) return
      Taro.showToast({ title: '地图选点失败，请重试', icon: 'none' })
    }
  }

  /** 保存行程并进入添加地点页面 */
  const handleSubmit = () => {
    if (!locationPicked) {
      Taro.showToast({ title: '请先在地图上选择酒店位置', icon: 'none' })
      return
    }

    const trip: Trip = {
      id: `trip-${Date.now()}`,
      title: title || `${city || '北京'}旅行`,
      city: city || '北京',
      startDate,
      endDate,
      hotel: {
        name: hotelName,
        address: hotelAddress,
        latitude: hotelLat,
        longitude: hotelLng
      },
      poiIds: [],
      dayCount: 3,
      assignMode: 'manual',
      poiDayMap: {}
    }

    upsertTrip(trip)
    Taro.redirectTo({ url: `/pages/poi/index?tripId=${trip.id}` })
  }

  return (
    <View className='page create-page'>
      <View className='card'>
        <Text className='label'>行程名称</Text>
        <Input className='input' value={title} onInput={(event) => setTitle(event.detail.value)} />
        <Text className='label'>目的地城市</Text>
        <Input className='input' value={city} onInput={(event) => setCity(event.detail.value)} />
        <Text className='city-hint'>内置景点库目前有北京、上海；其他城市请在下一步用地图选点添加地点。</Text>
        <Text className='label'>开始日期</Text>
        <Input className='input' type='text' value={startDate} onInput={(event) => setStartDate(event.detail.value)} />
        <Text className='label'>结束日期</Text>
        <Input className='input' type='text' value={endDate} onInput={(event) => setEndDate(event.detail.value)} />

        <Text className='label'>酒店位置</Text>
        <View className='hotel-picker' onClick={handlePickHotel}>
          {locationPicked ? (
            <View className='hotel-info'>
              <Text className='hotel-name'>{hotelName}</Text>
              <Text className='hotel-address'>{hotelAddress}</Text>
            </View>
          ) : (
            <Text className='hotel-placeholder'>点击在地图上选择酒店位置</Text>
          )}
          <Text className='hotel-arrow'>›</Text>
        </View>
      </View>

      <Button className='primary-button' onClick={handleSubmit}>
        下一步
      </Button>
    </View>
  )
}
