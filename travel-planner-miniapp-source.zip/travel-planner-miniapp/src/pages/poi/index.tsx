import { Button, Checkbox, Input, Text, View } from '@tarojs/components'
import Taro, { useLoad } from '@tarojs/taro'
import { useMemo, useState } from 'react'

import { createCustomPoi, getAvailablePois } from '../../utils/poi'
import { getTrip, upsertTrip } from '../../utils/storage'
import type { Poi, Trip } from '../../types/travel'
import './index.scss'

export default function SelectPoi() {
  // 当前行程
  const [trip, setTrip] = useState<Trip>()
  // 用户选择的景点 ID
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  // 行程内新增地点
  const [customPois, setCustomPois] = useState<Poi[]>([])
  // 景点搜索关键词
  const [keyword, setKeyword] = useState('')
  // 地图选点错误提示
  const [mapError, setMapError] = useState('')

  useLoad((params) => {
    const current = params.tripId ? getTrip(params.tripId) : undefined
    setTrip(current)
    setSelectedIds(current?.poiIds || [])
    setCustomPois(current?.customPois || [])
  })

  const availablePois = useMemo(
    () => getAvailablePois(trip ? { ...trip, customPois } : undefined),
    [trip, customPois]
  )

  const trimmedKeyword = keyword.trim()
  const matchedPois = availablePois.filter(
    (poi) =>
      trimmedKeyword === '' ||
      poi.name.includes(trimmedKeyword) ||
      poi.category.includes(trimmedKeyword) ||
      poi.address.includes(trimmedKeyword)
  )
  const hasSearch = trimmedKeyword.length > 0
  const selectedPois = availablePois.filter((poi) => selectedIds.includes(poi.id))

  /** 把新地点加入行程并默认勾选 */
  const addCustomPoi = (poi: Poi) => {
    setCustomPois((prev) => [poi, ...prev])
    setSelectedIds((prev) => (prev.includes(poi.id) ? prev : [poi.id, ...prev]))
    setKeyword('')
    setMapError('')
    Taro.showToast({ title: '已添加', icon: 'success' })
  }

  /** 用户主动点击「去地图选点」时才打开地图，不自动跳转 */
  const handleAddFromMap = async () => {
    setMapError('')
    try {
      // 首次使用先申请授权，避免「授权后还要再点一次」的问题
      const setting = await Taro.getSetting()
      const authState = setting.authSetting['scope.userLocation']
      if (authState === false) {
        const modal = await Taro.showModal({
          title: '需要位置权限',
          content: '请在设置中开启位置权限后，再选择地点',
          confirmText: '去设置'
        })
        if (modal.confirm) {
          await Taro.openSetting({})
        }
        return
      }
      if (authState === undefined) {
        try {
          await Taro.authorize({ scope: 'scope.userLocation' })
        } catch {
          setMapError('未授权位置权限，请允许后重试')
          return
        }
      }

      const result = await Taro.chooseLocation({
        latitude: trip?.hotel.latitude,
        longitude: trip?.hotel.longitude
      })
      if (!result.name && !result.address) {
        Taro.showToast({ title: '未选择地点', icon: 'none' })
        return
      }
      const poi = createCustomPoi({
        name: result.name || result.address || trimmedKeyword,
        address: result.address || result.name || trimmedKeyword,
        latitude: result.latitude,
        longitude: result.longitude,
        city: trip?.city || '北京'
      })
      addCustomPoi(poi)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      if (message.includes('cancel') || message.includes('取消')) return
      if (message.includes('requiredPrivateInfos') || message.includes('privacy')) {
        setMapError('地图选点未声明隐私接口，请重新编译后再试')
        return
      }
      if (message.includes('auth') || message.includes('authorize') || message.includes('permission')) {
        setMapError('未授权位置权限，请允许后重试')
        return
      }
      setMapError(`地图选点失败：${message || '请重试'}`)
    }
  }

  /** 单个景点勾选/取消，不覆盖其他已选项 */
  const togglePoi = (poiId: string) => {
    setSelectedIds((prev) => (prev.includes(poiId) ? prev.filter((id) => id !== poiId) : [...prev, poiId]))
  }

  /** 保存已选景点，进入分配页面 */
  const handleNext = () => {
    if (!trip) return
    if (!selectedIds.length) {
      Taro.showToast({ title: '请至少选择一个景点', icon: 'none' })
      return
    }

    const nextTrip: Trip = {
      ...trip,
      poiIds: selectedIds,
      customPois
    }
    upsertTrip(nextTrip)
    Taro.navigateTo({ url: `/pages/assign/index?tripId=${trip.id}` })
  }

  return (
    <View className='page poi-page'>
      <View className='search-box'>
        <Input
          className='search-input'
          placeholder='搜索景点名称、类型或地址'
          value={keyword}
          onInput={(event) => setKeyword(event.detail.value)}
        />
        {keyword && (
          <View className='clear-search' onClick={() => setKeyword('')}>
            <Text className='clear-search-icon'>×</Text>
          </View>
        )}
      </View>

      {hasSearch && (
        <View className='map-hint-card'>
          <Text className='muted'>{matchedPois.length ? '没有想要的？' : `没有找到「${trimmedKeyword}」`}</Text>
          <Button className='map-add-button' size='mini' onClick={handleAddFromMap}>
            没搜到？去地图选点
          </Button>
        </View>
      )}
      {mapError && <Text className='capacity-warning'>{mapError}</Text>}

      {selectedPois.length > 0 && (
        <View className='card selected-card'>
          <Text className='card-title'>已选 {selectedPois.length} 个</Text>
          <Text className='muted'>{selectedPois.map((poi) => poi.name).join('、')}</Text>
        </View>
      )}

      {matchedPois.length ? (
        matchedPois.map((poi: Poi) => (
          <View className='card poi-option' key={poi.id} onClick={() => togglePoi(poi.id)}>
            <Checkbox value={poi.id} checked={selectedIds.includes(poi.id)} />
            <View className='poi-copy'>
              <Text className='card-title'>{poi.name}</Text>
              <Text className='muted'>
                {poi.category} · {poi.visitMinutes} 分钟 · {poi.openingHours}
              </Text>
              <Text className='muted'>{poi.address}</Text>
              {poi.bookingRule.requiresBooking && <Text className='booking-tag'>需要预约</Text>}
            </View>
          </View>
        ))
      ) : (
        <View className='card muted'>没有匹配的景点，点上面「去地图选点」添加这个地方。</View>
      )}

      <View className='bottom-spacer' />

      <View className='bottom-bar'>
        <Button className='primary-button bottom-button' onClick={handleNext}>
          已选 {selectedIds.length} 个，下一步
        </Button>
      </View>
    </View>
  )
}
