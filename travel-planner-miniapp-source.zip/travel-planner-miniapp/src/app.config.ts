export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/create/index',
    'pages/detail/index',
    'pages/poi/index',
    'pages/assign/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#f7f9f8',
    navigationBarTitleText: '旅途有谱',
    navigationBarTextStyle: 'black'
  },
  permission: {
    'scope.userLocation': {
      desc: '用于在地图中选择想去的地点'
    }
  },
  requiredPrivateInfos: ['chooseLocation', 'getLocation']
})
